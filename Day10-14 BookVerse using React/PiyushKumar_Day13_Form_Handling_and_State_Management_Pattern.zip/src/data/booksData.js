// Sample data for featured books used in BookList

const booksData = [
    { id: 1, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 2, title: "The Alchemist", author: "Paulo Coelho", price: 299 },
    { id: 3, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 399 },
    { id: 4, title: "Deep Work", author: "Cal Newport", price: 450 },
    { id: 5, title: "Ikigai", author: "Héctor García", price: 350 },
];

export default booksData;
