# 📘 Day 17 --- Node.js Core Modules (Project)

This project includes solutions to three challenges based on **Node.js
core modules**: - **File System (`fs`)** - **HTTP module** - **Events
module (`EventEmitter`)**

## 📂 Project Structure

    day17-nodejs/
    │
    ├── challenge4_fs.js
    ├── challenge5_http.js
    ├── challenge6_events.js
    ├── index.html
    └── feedback.txt
    

# 🚀 Challenge 4 --- File System Module (fs)

### Goal

-   Accept CLI input
-   Write it to `feedback.txt`
-   Read and display file content

### Run

    node challenge4_fs.js "Your text here"

# 🌐 Challenge 5 --- HTTP Module

### Routes

-   `/` → static HTML or text
-   `/about`
-   others → 404

### Run

    node challenge5_http.js

# ⚡ Challenge 6 --- Events Module

Simulates: - `userLoggedIn` - `userLoggedOut` - `sessionExpired` (bonus)

### Run

    node challenge6_events.js
