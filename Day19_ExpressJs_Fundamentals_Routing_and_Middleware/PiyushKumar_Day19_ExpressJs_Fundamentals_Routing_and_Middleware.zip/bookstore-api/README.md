# Express Bookstore API

## Install
npm install

## Run
node server.js

## Endpoints
GET /books
POST /books
PUT /books/:id
DELETE /books/:id
